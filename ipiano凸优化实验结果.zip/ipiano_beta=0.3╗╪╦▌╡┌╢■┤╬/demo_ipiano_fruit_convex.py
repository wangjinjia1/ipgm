#!/usr/bin/env python
# -*- coding: utf-8 -*-
# This file is part of the SPORCO package. Details of the copyright
# and user license can be found in the 'LICENSE.txt' file distributed
# with the package.

"""
Convolutional Dictionary Learning
=================================

This example demonstrates the use of :class:`.cbpdndl.ConvBPDNDictLearn` for learning a convolutional dictionary from a set of colour training images :cite:`wohlberg-2016-convolutional`, using piano solvers for both sparse coding :cite:`chalasani-2013-fast` :cite:`wohlberg-2016-efficient` and dictionary update steps :cite:`garcia-2018-convolutional1`.
"""


from __future__ import print_function
from builtins import input

import pyfftw   # See https://github.com/pyFFTW/pyFFTW/issues/40
import numpy as np

from sporco.dictlrn import cbpdndl_slice as cbpdndl
from sporco import util
from sporco import signal
from sporco import plot
from sporco import metric
# from sporco.palm.backtrack import BacktrackStandardPeng2225
# from sporco.palm.stepsize import StepSizePolicyPengSingle
from sporco.ipiano.backtrack import BacktrackStandardPeng2225
from sporco.ipiano.stepsize import StepSizePolicyPeng2124
from sporco.fft import fftn, ifftn
from sporco.signal import local_contrast_normalise
from sporco.cnvrep import zeromean
from sporco.prox import _lp


import torch
import torch.nn.functional as F

"""
Load training Data fruit.
"""

print("python demo_ipiano_fruit.py")

M = 100
Nd = 11
exim = util.ExampleImages(scaled=True, zoom=1, gray=True,pth='fblpdemo/fruit_100_100/')


im = exim.images()
K = len(im)
dimk=1
img0= exim.image(im[0], scaled=True, dtype=np.float32)
N = img0.shape[0]
Imgref = np.zeros((N,N,K))

for k in range(K):
    s1 = exim.image(im[k], dtype=np.float32)  #scaled=True,
    s2 = local_contrast_normalise(zeromean(s1,(Nd, Nd)),n=Nd)
    print("EXPeriment 2 for  method ipiano slice, fruit img:",s2[0].shape)
    Imgref[...,k] = s2[0]
print("EXPeriment 2 for  method ipiano slice, Synthetic img:",Imgref.shape)  #




"""
Set regularization parameter and options for dictionary learning solver. Note the multi-scale dictionary filter sizes. Also note the possibility of changing parameters in the backtracking algorithm.
"""


MIter = 1000
beta = 0.3 #beta = None
L_sc = 1e3#1e2#
L_du = 1e3#1e2#

dsz = (Nd, Nd, M)  # right
lmbda = 1
"""
Construct initial dictionary.
"""
# D0 = np.random.randn(Nd, Nd, M)  #non-convex. [0,1], 0.1=sqrt(m)/m
# A0 = np.random.randn(N, N, 1, K, M)  # nonconvex 
# datainit_randn = np.savez('fblpdemo/datainit_randn_fruit.npz', D0=D0, A0=A0) 


convexflag = True
#convexflag = False
if convexflag == True: 
    datainit_randn = np.load('fblpdemo/datainit_randn_fruit.npz')
    D0 = datainit_randn['D0']
    A0 = datainit_randn['A0']
    #print("convex,beta,MIter",beta,MIter)
    print("convex,lmbda,beta,MIter,L=",lmbda,beta,MIter,L_sc)
else:
    datainit_palm = np.load('fblpdemo/fruit_ipiano_convex.npz')
    D0 = datainit_palm['D0']
    A0 = datainit_palm['A0']
    #print("nonconvex,beta,MIter",beta,MIter)
    print("nonconvex,lmbda,beta,MIter,L=",lmbda,beta,MIter,L_sc)

#print("demo, init(), time domain D0:",D0.shape,"time domain A0:",A0.shape)
coefA = 0.0
#coefA = 0.080
#A0 = coefA * datainit_randn['A0']

opt = cbpdndl.ConvBPDNDictLearn.Options(
        {
         'Verbose': True, 'MaxMainIter': MIter, 'DictSize':dsz,                   
         'CSCCDL': { 'L_D': L_sc,'L_A': L_du,
                     'Beta': beta  # None for beta=(k-1)/(k+2)
                    #,'Convex': True #, 'A0': A0 ,'D0': D0 #'FastSolve':False,
                    , 'Backtrack': BacktrackStandardPeng2225(gamma_u=1.1)
                    ,'StepSizePolicy':StepSizePolicyPeng2124()
                    }
        },
            xmethod='ipiano'
            )


"""
Create solver object and solve.
"""
lpfflag = 1
if lpfflag == 1:
    npd = 16
    fltlmbd = 5
    sl, sh = signal.tikhonov_filter(Imgref, fltlmbd, npd)
    d = cbpdndl.ConvBPDNDictLearn(sh, D0, lmbda, opt, xmethod='ipiano',  dimK=1)
    [D1,alpha1] = d.solve()  #
    imgdp = d.reconstruct().squeeze() + sl
    imgdp_slice = d.reconstruct_slice_torch().squeeze() + sl

else:
    d = cbpdndl.ConvBPDNDictLearn(Imgref, D0, lmbda, opt, xmethod='ipiano', dimK=1)
    [D1,alpha1] = d.solve()  #
    imgdp = d.reconstruct().squeeze()
    imgdp_slice = d.reconstruct_slice_torch().squeeze() + sl



its = d.getitstat()

psnrImg = metric.psnr(Imgref,imgdp)
psnrImg_slice = metric.psnr_slice(Imgref,imgdp_slice)       # 28

sumnnz  = np.count_nonzero(alpha1) # np.count_nonzero # np.count_nonzero(a, axis=1, keepdims=True)
#rl1 = np.linalg.norm((alpha1).ravel(), 0) # the same
#rl1 = _lp.norm_l0((alpha1).ravel())       # the same
sumnumel = np.prod(alpha1.shape)
sparsity = sumnnz/sumnumel # torch.count_nonzero(X0) / torch.numel(X0) 

if convexflag == True: 
    #print("convex,beta,MIter",beta,MIter)
    print("convex,lmbda,beta,MIter,L=",lmbda,beta,MIter,L_sc)
    print("init alpha=%0.4f*randn(),iter=%0.0f,Time=%0.4f s, %0.1f * %.4f(sparsity%.6f)+ %.4f(PSNR,%.4fdB,%.4fdB)= %.4f\n" \
        % (coefA,its.Iter[-1],its.Time[-1],lmbda,its.RegL1[-1],sparsity,its.DFid[-1],psnrImg,psnrImg_slice,its.ObjFun[-1]))

    datainit_palm = np.savez('fblpdemo/fruit_ipiano_convex.npz', D0=D1, A0=alpha1) 
else:
    #print("nonconvex,beta,MIter",beta,MIter)
    print("nonconvex,lmbda,beta,MIter,L=",lmbda,beta,MIter,L_sc)
    print("init alpha=convex,iter=%0.0f,Time=%0.4f s, %0.1f * %.4f(sparsity%.6f)+ %.4f(PSNR,%.4fdB,%.4fdB)= %.4f\n" \
        % (its.Iter[-1],its.Time[-1],lmbda,its.RegL1[-1],sparsity,its.DFid[-1],psnrImg,psnrImg_slice,its.ObjFun[-1]))

    datainit_palm_nonconvex = np.savez('fblpdemo/fruit_ipiano_nonconvex.npz', D0=D1, A0=alpha1) 





#Dt = torch.from_numpy(D1.squeeze()) 
#print(Dt.mean(),Dt.var(),torch.mean(Dt,dim=(-3,-2)),torch.norm(Dt, p="fro", dim=(-3,-2)))
# it is right, ||.||=1
# https://blog.csdn.net/jpch89/article/details/84099277

"""
Display initial and final dictionaries.
"""

#plot.axis('off')
D1 = D1.squeeze() #
fig = plot.figure(figsize=(5, 5))
plot.imview(util.tiledict(D1), fig=fig)
file_name = 'fblpdemo/fruit_ipiano_D'
stat_name = '_PSNR{:.4f}dB_sparsity{:.4%}_time{:.4f}s'\
.format(psnrImg_slice,sparsity,d.timer.elapsed('solve_wo_eval'))
png_Dname = file_name + stat_name +'.png'
# supported formats: eps, jpeg, jpg, pdf, pgf, png, ps, raw, rgba, svg, svgz, tif, tiff)
plot.savefig(png_Dname,dpi=500,bbox_inches = 'tight')
"""png_Dname = file_name + stat_name +'.eps'
plot.savefig(png_Dname)
png_Dname = file_name + stat_name +'.pdf'
plot.savefig(png_Dname)


fig = plot.figure(figsize=(21, 14))
plot.subplot(2, 1, 1)
plot.imview(Imgref[:,:,1], title='Reference', fig=fig)
plot.subplot(2, 1, 2)
plot.imview(imgdp[:,:,1], title='Reconstruction', fig=fig)

file_name = 'fblpdemo/fruit_palm_Img'
stat_name = '_PSNR{:.4f}dB_sparsity{:.4%}_time{:.4f}s'\
.format(psnrImg_slice,sparsity,d.timer.elapsed('solve_wo_eval'))
png_Dname = file_name + stat_name +'.png'
# supported formats: eps, jpeg, jpg, pdf, pgf, png, ps, raw, rgba, svg, svgz, tif, tiff)
plot.savefig(png_Dname)"""

fig = plot.figure(figsize=(7, 7))
# plot.imview(imgdp[:,:,1],  fig=fig)
plot.imview(imgdp_slice[:,:,2],  fig=fig)  # 1 is banana, 2 is pepper
file_name = 'fblpdemo/fruit_ipiano_ImgReconstruction'
stat_name = '_PSNR{:.4f}dB_sparsity{:.4%}_time{:.4f}s'\
.format(psnrImg_slice,sparsity,d.timer.elapsed('solve_wo_eval'))
png_Dname = file_name + stat_name +'.png'
plot.savefig(png_Dname,dpi=500,bbox_inches = 'tight')
"""png_Dname = file_name + stat_name +'.eps'
plot.savefig(png_Dname)
png_Dname = file_name + stat_name +'.pdf'
plot.savefig(png_Dname)"""


"""
Get iterations statistics from solver object and plot functional value, residuals, and automatically adjusted gradient step parameters against the iteration number.
"""

fig = plot.figure(figsize=(20, 5))
plot.subplot(1, 3, 1)
plot.plot(its.ObjFun, xlbl='Iterations', ylbl='Functional',  fig=fig)
#plot.ylim(1.0e4,2.8e4)
plot.subplot(1, 3, 2)
plot.plot(np.vstack((its.X_Rsdl, its.D_Rsdl)).T,
          ptyp='semilogy', xlbl='Iterations', ylbl='Residual',
          lgnd=['X', 'D'], fig=fig)
plot.subplot(1, 3, 3)
plot.plot(np.vstack((its.X_L, its.D_L)).T, xlbl='Iterations',
          ylbl='Inverse of Gradient Step Parameter', ptyp='semilogy',
          lgnd=['$L_X$', '$L_D$'], fig=fig)

file_name = 'fblpdemo/fruit_ipiano_Stat_'
stat_name = '_PSNR{:.4f}dB_sparsity{:.4%}_time{:.4f}s'\
.format(psnrImg_slice,sparsity,d.timer.elapsed('solve_wo_eval'))
png_name = file_name + stat_name +'.png'
# str format # https://blog.csdn.net/jpch89/article/details/84099277
# supported formats: eps, jpeg, jpg, pdf, pgf, png, ps, raw, rgba, svg, svgz, tif, tiff)
plot.savefig(png_name,dpi=500,bbox_inches = 'tight')

plot.close()

performanceV = '_PSNR{:.4f}dB'.format(psnrImg_slice) \
    + '_{:.4f}s'.format(d.timer.elapsed('solve')) +'_{:.6f}sparsity'.format(sparsity)
txt_name = file_name + performanceV+'.txt'
np.savetxt(txt_name,np.c_[its.Iter,its.Time,its.ObjFun,its.DFid,its.RegL1,its.Cnstr,\
                        its.X_Rsdl,its.D_Rsdl,\
                        its.X_L,its.D_L])
                        #its.X_F_Btrack,its.X_Q_Btrack,its.X_ItBt,its.X_L,\
                        #its.D_F_Btrack,its.D_Q_Btrack,its.D_ItBt,its.D_L])

# Wait for enter on keyboard
#input()

